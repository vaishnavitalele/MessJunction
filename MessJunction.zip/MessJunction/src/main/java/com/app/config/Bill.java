package com.app.config;



import com.app.model.Customer;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class Bill {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
	private int orderid;
	private String name;
	private int price;
	
	@OneToOne(targetEntity = Customer.class,cascade = CascadeType.ALL)
	@JoinColumn(columnDefinition = "id",referencedColumnName = "id")
	public int getId() {
		return orderid;
	}
	public void setId(int id) {
		this.orderid = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Bill [id=" + orderid + ", name=" + name + ", price=" + price + "]";
	}
	
	
}
