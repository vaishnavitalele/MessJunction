package com.app.menu.dto;




public class BillRequest {
	
	
	

}
