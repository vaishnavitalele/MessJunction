package com.app.order.service;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.config.Bill;
import com.app.controller.OrderResponse;
import com.app.menu.dao.impl.OrderServiceDaoImpl;
import com.app.menu.dto.OrderRequest;
import com.app.model.Menu;
import com.app.repository.BillRepository;
import com.app.repository.OrderRepository;




@Service

public class OrderService {
	
	private int amount=0;
	private List<MenuResponse>list;
	
	 
	
	
	@Autowired
	OrderServiceDaoImpl order;

	public MenuResponse getOrder(int id, int mul) {
		// TODO Auto-generated method stub
		
		
		
		MenuResponse bill=new MenuResponse();
		Menu menu=order.getOrderById(id);
		bill.setId(id);
		bill.setName(menu.getName());
		bill.setPrice(menu.getPrice());
		
		generateBill(menu.getId(),menu.getName(),menu.getPrice(),mul);
		
		setAmount(menu.getPrice()*mul);
	
		return bill;
	}
	
	



	public void generateBill(int orderid,String name,int price, int mul) {
		
		File file=new File("d://bill.txt");
		
		
		try {
			FileWriter writer=new FileWriter(file,true);
			
			
			setAmount(price*mul);
			writer.write("\n"+orderid+"\t"+name+"\t\t"+mul+"\t"+price+"\t"+price*mul+"\t");
			
			writer.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			
			System.err.print("Sorry bill is not generated");
			e.printStackTrace();
		}
		
		


	}

@Autowired
OrderRepository repo;
	public OrderResponse addMenu(OrderRequest request,int Id) {
		// TODO Auto-generated method stub
		
		Menu menu=new Menu();
		menu.setId(request.getId());
		menu.setName(request.getName());
		menu.setPrice(request.getPrice());
		Menu menu2=order.getOrderById(Id);
		System.out.println(menu2);
	     Menu res=repo.save(menu2);
		
		OrderResponse menuResponse=new OrderResponse();
		menuResponse.setId(res.getId());
		menuResponse.setName(res.getName());
		menuResponse.setPrice(res.getPrice());
		setAmount(res.getPrice());
		
		return menuResponse;
		
		
	}
	
	
	
	public int getAmount() {
		return amount;
	}



	public void setAmount(int amount) {
		this.amount += amount;
	}



	


	public List<MenuResponse> getList() {
		return list;
	}





	





	
	



	

	}
