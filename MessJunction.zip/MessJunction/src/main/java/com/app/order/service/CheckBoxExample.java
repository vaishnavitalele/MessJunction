package com.app.order.service;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.ListIterator;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import com.app.model.Menu;  
public class CheckBoxExample extends JFrame implements ActionListener{  
    JLabel l;  
    JCheckBox cb1,cb2,cb3,cb4,cb5;  
    JButton b;  
   public void getBill(Menu menu){  
        l=new JLabel("Food Ordering System");  
       
        l.setBounds(50,50,300,20);  
        cb1=new JCheckBox(menu.getName()+"@ "+menu.getPrice());  
        cb1.setBounds(100,100,150,20);  
        cb2=new JCheckBox();  
        cb2.setBounds(100,150,150,20);  
        cb3=new JCheckBox("Dal_Rice @ 50");  
        cb3.setBounds(100,200,150,20); 
        
        
        b=new JButton("Order");  
        b.setBounds(100,250,80,30);  
        b.addActionListener(this);  
        add(l);add(cb1);add(cb2);add(cb3);add(b);  
        setSize(400,400);  
        setLayout(null);  
        setVisible(true);  
        setDefaultCloseOperation(EXIT_ON_CLOSE);  
    }  
    public void actionPerformed(ActionEvent e){  
        float amount=0;  
        String msg="";  
        if(cb1.isSelected()){  
            amount+=100;  
            msg="Matar_Paneer: 100\n";  
        }  
        if(cb2.isSelected()){  
            amount+=70;  
            msg+="Aaloo-roti: 70\n";  
        }  
        if(cb3.isSelected()){  
            amount+=50;  
            msg+="Dal_Rice: 50\n";  
        } 
       
        msg+="-----------------\n";  
        JOptionPane.showMessageDialog(this,msg+"Total: "+amount);  
        
 
    }  
    public static void main(String[] args) {  
        new CheckBoxExample();  
    }  
}  
