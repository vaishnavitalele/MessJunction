package com.app.dao;




import org.springframework.stereotype.Repository;

import com.app.model.Admin;


@Repository
public interface AdminDao {
	
	public Admin getadminbyId(String userId);

}
