package com.app.dao.impl;



import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.app.dao.AdminDao;
import com.app.model.Admin;

import jakarta.annotation.PostConstruct;

@Configuration
public class AdminDaoImpl extends JdbcDaoSupport implements AdminDao{

//	@Override
//	public Admin getadminbyId(String userId)  {
//		// TODO Auto-generated method stub
//		
//		String sql = """
//		           SELECT id, first_name,last_name,email
//		           FROM employee
//		           LIMIT 100;
//		           """;
//		   return JdbcTemplate.query(sql,new RowMapper());
//		
//		
//		
//		
//		
//		
//		
//		
//		return null;
//	}
	
//@Bean
//	private JdbcTemplate getTemplate(HikariDataSource datasource) {
//		return new JdbcTemplate(datasource);
//		
//		
//	}
//	private Admin getById(String userId) throws Exception {
//		
//		String sql="select password from admin where username=?";
//		return null;
//		//query(sql,new DataClassRowMapper(),userId).stream().findFirst();
//		
//	}
	
	@Autowired DataSource datasource;
	@PostConstruct
	private void init() {
		setDataSource(datasource);
	}
//
	@Override
	public Admin getadminbyId(String userId) {
		// TODO Auto-generated method stub		
		String sql="select password from admin where username=?";
		
		
	return getJdbcTemplate().queryForObject(sql, new Object[] {userId},new RowMapper<Admin>(){
			
			public Admin mapRow(ResultSet rs, int rowNum)throws SQLException{
				Admin cust=new Admin();
				cust.setUsername(userId);
				cust.setPassword(rs.getString(1));
				return cust;
			}
			});
		
	}

	
}
