package com.app.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.bind.annotation.RestController;



import com.app.menu.dto.OrderRequest;

import com.app.order.service.MenuResponse;
import com.app.order.service.OrderService;


@RestController()

public class OrderController {
	
	private List<MenuResponse>list;
	
	
	
	
	


	@Autowired OrderService orderService;
	

	 @GetMapping("/order")
		public MenuResponse getOrder(@RequestParam int id, @RequestParam int mul){
		 
		 MenuResponse response=orderService.getOrder(id, mul);
		// list.add(response);
		orderService.getAmount();
		
		
			return response;
		}
	// @Autowired OrderRequest request;
	 
//	 @PostMapping("/order/generatebill")
//	 public ResponseEntity<OrderResponse> generateBill() {
//		 //orderService.getOrder(total, total);
//		 MenuResponse response=orderService.addMenu(request);
//		 return new ResponseEntity<>(response,HttpStatus.OK);
//		 
//		
//		 
//	 }
	 
	
//	 @PostMapping("/addmenu")
//		public ResponseEntity<MenuResponse>addCustomer(@RequestBody OrderRequest order,@RequestParam int id,@RequestParam int mul){
//		 OrderResponse order=orderService.getOrder(id, mul);
//			return new ResponseEntity<MenuResponse>(orderService.addMenu(order,id), HttpStatus.OK);
//		}
//	 
	 
	 
		/*
		 * @PostMapping("/addorder") public ResponseEntity<MenuResponse>
		 * addMenu(@RequestBody OrderRequest request){ MenuResponse
		 * response=orderService.addMenu(request,); return new
		 * ResponseEntity<>(response,HttpStatus.OK); }
		 */
	
		 
	 
	 public List<MenuResponse> getList() {
			return list;
		}


		public void setList(List<MenuResponse> list) {
			this.list = list;
		}

}
