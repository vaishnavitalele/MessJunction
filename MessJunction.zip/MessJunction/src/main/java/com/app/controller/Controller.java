package com.app.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.app.model.Contact;

@RestController
@Configuration("/login")
public class Controller {
	ConcurrentHashMap<String, Contact>contact=new ConcurrentHashMap<String, Contact>();
	
	@GetMapping("/{id}")
	public Contact addContact(@PathVariable String id) {
		return contact.get(id);
		
		
	}
	@GetMapping("/")
	public List<Contact> getAllContact(){
		return new ArrayList<Contact>(contact.values());
		
		
	}
	
	
	
//	public Contact addContact(@RequestBody Contact contact) {
//		contact.put(contact.getId(),contact);
//		return contact;
//	}

}
