package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.service.AdminService;

@RestController
public class AdminController {
	
	@Autowired
	AdminService adminService;
	
	@PostMapping("/adminlogin")
	
	public String getAdminById(@RequestParam String username,@RequestParam String password) {
		
	AdminResponse response=adminService.getAdminById(username);
	
	if(response.getUsername().equals(username)&response.getPassword().equals(password))
	
	return "Welcome"+response.getUsername();
	
	return null;
	
		
	}
	
	

}
