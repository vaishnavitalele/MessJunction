package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.app.controller.AdminResponse;
import com.app.dao.AdminDao;
import com.app.model.Admin;
@Service
public class AdminService {
@Autowired
AdminDao repo;
	public AdminResponse getAdminById(String username) {
		// TODO Auto-generated method stub
		
		Admin admin=repo.getadminbyId(username);
		AdminResponse reponse =new AdminResponse();
		
		reponse.setUsername(username);
		reponse.setPassword(admin.getPassword());
		return reponse;
		
		
	}

}
